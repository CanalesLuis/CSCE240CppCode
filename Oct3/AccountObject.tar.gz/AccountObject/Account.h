/***************************************************************************
 * Name: Casey Cole
 * Email: coleca@email.sc.edu
 * Function: Account object header
 * 
 * Copyright (C) 2019 by Casey Cole                                        *
 *                                                                         *
 ***************************************************************************/

using namespace std;
/*
 * The following will define the member variables as well as the functions 
 * of the Account object. 
 * */
 
 
class Account {
	public:			
	
		//Constructors
		//Account(); 
		
		//Functions
		
		//Member variables??
    
	private:		//Why make something private?
    

};
