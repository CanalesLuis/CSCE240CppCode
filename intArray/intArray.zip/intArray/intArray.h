//cannot change the presedence of operators
//cannot change the number of operands (arguments)

#include <iostream>
using namespace std;

class intArray 
{

public:
    intArray();
    intArray(int _size);
    intArray(int _size, int array[]);
    intArray(const intArray&);
    ~intArray(); 
    
    void Print();
    void PrintSize();
    int Size();
    
    /*
    int operator[](int);  
    void operator()(int,int); 
    */
    
    /*
    void operator-(); //unary, however this is not 
    				  //really how we want this to work... 
    */
    
    /*
    void operator+(int);
    void operator+(intArray&);
    void operator=(intArray&);
    */
    
    /*
    intArray& operator=(intArray);
    intArray operator+(intArray&);
    */
     
    /*
    void operator<<(ostream& os);
    */
    
    /*
    intArray& operator++(int); //post
    intArray& operator++(); //pre
    */
private:
    int size;
    int *data;

};


