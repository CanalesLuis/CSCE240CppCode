#include <iostream>
#include <cstdlib>
#include "intArray.h"

using namespace std;

int main (int argc, char **argv)
{ 
	
	intArray obj1; 
	
	intArray obj2(10);
	
	intArray obj3(obj2); 
	
	obj3.Print();

	
	return 0; 
}
