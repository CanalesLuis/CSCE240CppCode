
#include "intArray.h"

intArray::intArray()
{
    size = 0;
	data = new int[size];
}

intArray::intArray(int _size, int array[])
{
	size = _size;
	data = new int[size];
	
	for(int i = 0; i < size; i++)
	{
		data[i] = array[i];
	}
	
}

intArray::intArray(int _size)
{
	size = _size;
	data = new int[size];
	
	for(int i = 0; i < size; i++)
	{
		data[i] = 0;
	}
	
}

intArray::intArray(const intArray& array2)
{
	size = array2.size; //since they are the same object type we
						//have access but we should use getter.
	
    data = new int[size];
   
    for(int i = 0; i < size; i++)
    {
        data[i] = array2.data[i];
    }
}

int intArray::Size()
{
	return size;
}

void intArray::Print()
{
    for(int i=0; i < size; i++) 
    {
        cout << data[i] << " ";
    }
    cout << endl;
}

void intArray::PrintSize()
{
    cout << "size: " << size << endl;
}


intArray::~intArray()
{
	delete [] data;
}
